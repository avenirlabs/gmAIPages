export default function handler(req, res) {
  // Set CORS headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  const { slug } = req.query;

  if (req.method === "GET") {
    return res.status(200).json({
      message: "Menu endpoint without any imports - testing if Supabase import causes 404",
      slug: slug || "no-slug-provided",
      timestamp: new Date().toISOString(),
      env_check: {
        hasUrl: !!process.env.SUPABASE_URL,
        hasKey: !!process.env.SUPABASE_SERVICE_ROLE_KEY
      }
    });
  }

  return res.status(405).json({ error: "Method not allowed" });
}